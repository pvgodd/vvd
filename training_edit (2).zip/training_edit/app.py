from flask import Flask, render_template, request, jsonify, send_file
import subprocess
from fpdf import FPDF
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/select-attack')
def select_attack():
    attacks = [
        "Atlassian Confluence",
        "Apache Struts2",
        "Apache OFBiz",
        "Cisco",
        "Citrix Bleed",
        "ProxyShell",
        "ProxyNotShell",
        "ShellShock",
        "SQL Injection",
        "VMware"
    ]
    return render_template('select_attack.html', attacks=attacks)

@app.route('/attack-form/<attack_type>/<vuln_id>')
def attack_form(attack_type, vuln_id):
    return render_template('attack_form.html', attack_type=attack_type, vuln_id=vuln_id)

@app.route('/run-attack/<attack_type>', methods=['POST'])
def run_attack(attack_type):
    data = request.get_json()
    url = data.get('url')
    cmd = data.get('cmd', '')
    vuln_id = data.get('vulnId', '')

    if not url:
        return jsonify({"error": "URL is required"}), 400

    try:
        if attack_type == "Atlassian Confluence" and vuln_id == "CVE-2022-26134":
            result = subprocess.run(['python3', 'tools/CVE-2022-26134.py', '-u', url, '-c', cmd], capture_output=True, text=True)
        elif attack_type == "Atlassian Confluence" and vuln_id == "CVE-2021-26084":
            result = subprocess.run(['python3', 'tools/CVE-2021-26084.py', '-u', url, '-c', cmd], capture_output=True, text=True)
        elif attack_type == "Atlassian Confluence" and vuln_id == "CVE-2022-22527":
            result = subprocess.run(['python3', 'tools/CVE-2022-22527.py', '-u', url, '-c', cmd], capture_output=True, text=True)
        elif attack_type == "Apache Struts2" and vuln_id == "CVE-2017-5638":
            result = subprocess.run(['python3', 'tools/CVE-2017-5638.py', '-u', url, '-c', cmd], capture_output=True, text=True)
        elif attack_type == "Apache OFBiz" and vuln_id == "CVE-2023-51467":
            result = subprocess.run(['python3', 'tools/CVE-2023-51467.py', '-u', url], capture_output=True, text=True)
        elif attack_type == "Apache OFBiz" and vuln_id == "CVE-2024-38856":
            result = subprocess.run(['python3', 'tools/CVE-2024-38856.py', '-u', url], capture_output=True, text=True)
        elif attack_type == "Cisco" and vuln_id == "CVE-2019-1653":
            result = subprocess.run(['python3', 'tools/CVE-2019-1653.py', '-u', url], capture_output=True, text=True)
        elif attack_type == "Cisco" and vuln_id == "CVE-2023-20198":
            result = subprocess.run(['python3', 'tools/CVE-2023-20198.py', '-u', url], capture_output=True, text=True)
        elif attack_type == "Citrix Bleed" and vuln_id == "CVE-2023-4966":
            result = subprocess.run(['python3', 'tools/CVE-2023-4966.py', '-u', url], capture_output=True, text=True)
        elif attack_type == "ProxyShell" and vuln_id == "CVE-2021-34473":
            result = subprocess.run(['python3', 'tools/CVE-2021-34473.py', '-u', url], capture_output=True, text=True)
        elif attack_type == "ProxyNotShell" and vuln_id == "CVE-2022-41082":
            result = subprocess.run(['python3', 'tools/CVE-2022-41082.py', '-u', url, '-c', cmd], capture_output=True, text=True)
        elif attack_type == "ShellShock" and vuln_id == "CVE-2014-6271":
            result = subprocess.run(['python3', 'tools/CVE-2014-6271.py', '-u', url, '-c', cmd], capture_output=True, text=True)
        elif attack_type == "SQL Injection":
            result = subprocess.run(['python3', 'tools/sql_injection.py', '-u', url], capture_output=True, text=True)
        elif attack_type == "VMware" and vuln_id == "CVE-2022-22954":
            result = subprocess.run(['python3', 'tools/CVE-2022-22954.py', '-u', url], capture_output=True, text=True)

        else:
            return jsonify({"error": f"지원되지 않는 공격 또는 취약점입니다: {attack_type} / {vuln_id}"}), 400

        output = result.stdout if result.returncode == 0 else result.stderr
        return jsonify({"output": output})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/download-pdf', methods=['POST'])
def download_pdf():
    data = request.get_json()
    output_content = data.get('output')
    attack_type = data.get('attackType')
    vuln_id = data.get('vulnId')

    if not output_content or not attack_type or not vuln_id:
        return jsonify({"error": "필수 데이터 누락"}), 400

    try:
        pdf = FPDF()
        pdf.add_page()

        # ✅ 나눔고딕 폰트 등록 (최초 1회만 등록)
        pdf.add_font('Nanum', '', '/usr/share/fonts/truetype/nanum/NanumGothic.ttf', uni=True)
        pdf.set_font('Nanum', '', 14)

        # 제목
        pdf.cell(0, 10, f"Attack Type: {attack_type} / Vulnerability: {vuln_id}", ln=True)
        pdf.ln(10)

        # 본문 출력
        pdf.set_font('Nanum', '', 12)
        pdf.multi_cell(0, 10, output_content)

        # 파일 저장
        filename = f'attack_result_{attack_type}_{vuln_id}.pdf'.replace(" ", "_")
        pdf.output(filename)

        return send_file(filename, as_attachment=True)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=80, host='0.0.0.0')

