from flask import Flask, render_template, request, jsonify
import subprocess

app = Flask(__name__)

# index.html 페이지 렌더링
@app.route('/')
def index():
    return render_template('index.html')

# 공격 카테고리 선택 페이지
@app.route('/select-attack')
def select_attack():
    attacks = [
        "Atlassian Confluence",
        "Apache Struts2",
        "Apache OFBiz",
        "Cisco",
        "Citrix Bleed",
        "ProxyShell"
        "ProxyNotShell",
        "ShellShock",
        "VMware"
    ]
    return render_template('select_attack.html', attacks=attacks)

# 공격 실행 API
@app.route('/run-attack/<attack_type>', methods=['POST'])
def run_attack(attack_type):
    data = request.get_json()
    url = data.get('url')

    if not url:
        return jsonify({"error": "URL is required"}), 400

    try:
        if attack_type == "Atlassian Confluence":
            result = subprocess.run(['python3', 'tools/confluence_attack.py', url], capture_output=True, text=True)
        elif attack_type == "Apache Struts2":
            result = subprocess.run(['python3', 'tools/struts2_attack.py', url], capture_output=True, text=True)
            print(result)
        elif attack_type == "Apache OFBiz":
            result = subprocess.run(['python3', 'tools/ofbiz_attack.py', url], capture_output=True, text=True)
        elif attack_type == "Cisco":
            result = subprocess.run(['python3', 'tools/cisco_attack.py', url], capture_output=True, text=True)
        elif attack_type == "Citrix Bleed":
            result = subprocess.run(['python3', 'tools/citrix_bleed_attack.py', url], capture_output=True, text=True)
        elif attack_type == "ProxyShell":
            result = subprocess.run(['python3', 'tools/proxyshell_attack.py', url], capture_output=True, text=True)
        elif attack_type == "ProxyNotShell":
            result = subprocess.run(['python3', 'tools/proxynotshell_attack.py', url], capture_output=True, text=True)
        elif attack_type == "ShellShock":
            result = subprocess.run(['python3', 'tools/shellshock_attack.py', url], capture_output=True, text=True)
        elif attack_type == "VMware":
            result = subprocess.run(['python3', 'tools/vmware_attack.py', url], capture_output=True, text=True)
        else:
            return jsonify({"error": "Invalid attack type"}), 400

        return jsonify({"output": result.stdout})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
