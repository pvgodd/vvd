from flask import Flask, render_template, request, jsonify, send_file
import subprocess
from fpdf import FPDF
from fpdf.enums import XPos, YPos
import os
from load_attacks import load_attacks
attack_definitions = load_attacks()
attack_lookup = {
    f"{a['attack_type']}::{a['vuln_id']}": a for a in attack_definitions
}

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/select-attack')
def select_attack():
    from collections import defaultdict
    attack_map = defaultdict(list)
    for a in attack_definitions:
        attack_map[a['attack_type']].append(a['vuln_id'])
    return render_template('select_attack.html', attack_map=attack_map)

@app.route('/attack-form/<attack_type>/<vuln_id>')
def attack_form(attack_type, vuln_id):
    return render_template('attack_form.html', attack_type=attack_type, vuln_id=vuln_id)

@app.route('/run-attack/<attack_type>', methods=['POST'])
def run_attack(attack_type):
    data = request.get_json()
    url = data.get('url')
    cmd = data.get('cmd', '')
    vuln_id = data.get('vulnId', '')

    if not url or not vuln_id:
        return jsonify({"error": "URL과 취약점 ID가 필요합니다."}), 400

    attack_key = f"{attack_type}::{vuln_id}"
    attack_info = attack_lookup.get(attack_key)

    if not attack_info:
        return jsonify({"error": f"등록되지 않은 취약점입니다: {attack_key}"}), 400

    script_path = os.path.join('tools', attack_info['file'])
    args = ['python3', script_path, '-u', url]
    if attack_info['support_cmd'] and cmd:
        args += ['-c', cmd]

    try:
        result = subprocess.run(args, capture_output=True, text=True)
        output = result.stdout if result.returncode == 0 else result.stderr
        return jsonify({"output": output})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/download-pdf', methods=['POST'])
def download_pdf():
    data = request.get_json()
    output_content = data.get('output')
    attack_type = data.get('attackType')
    vuln_id = data.get('vulnId')

    if not output_content or not attack_type or not vuln_id:
        return jsonify({"error": "필수 데이터 누락"}), 400

    try:
        # 디렉터리 생성
        result_dir = 'result'
        os.makedirs(result_dir, exist_ok=True)

        filename = f'attack_result_{attack_type}_{vuln_id}.pdf'.replace(" ", "_")
        filepath = os.path.join(result_dir, filename)

        # PDF 생성
        pdf = FPDF()
        pdf.add_page()
        pdf.add_font('Nanum', '', '/usr/share/fonts/truetype/nanum/NanumGothic.ttf')
        pdf.set_font('Nanum', '', 14)
        pdf.cell(0, 10, f"Attack Type: {attack_type} / Vulnerability: {vuln_id}",
                 new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(5)

        pdf.set_font('Nanum', '', 12)
        pdf.multi_cell(0, 10, output_content)

        pdf.output(filepath)
        return send_file(os.path.abspath(filepath), as_attachment=True)

    except Exception as e:
        print(f"오류 발생: {e}")
        return jsonify({"error": f"PDF 생성 실패: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True, port=80, host='0.0.0.0')


