import os
import re

def load_attacks(tool_dir='tools'):
    attacks = []

    for fname in os.listdir(tool_dir):
        if not fname.endswith('.py'):
            continue

        path = os.path.join(tool_dir, fname)
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()

            attack_type = re.search(r'#\s*ATTACK_TYPE:\s*(.+)', content)
            vuln_id = re.search(r'#\s*VULN_ID:\s*(.+)', content)
            support_cmd = re.search(r'#\s*SUPPORT_CMD:\s*(.+)', content)

            if attack_type and vuln_id:
                attacks.append({
                    'file': fname,
                    'attack_type': attack_type.group(1).strip(),
                    'vuln_id': vuln_id.group(1).strip(),
                    'support_cmd': support_cmd.group(1).strip().lower() == 'true' if support_cmd else False
                })

    return attacks

