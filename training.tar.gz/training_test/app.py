from flask import Flask, render_template, request, jsonify
import subprocess

app = Flask(__name__)

# index.html 페이지 렌더링
@app.route('/')
def index():
    return render_template('index.html')

# 공격 카테고리 선택 페이지
@app.route('/select-attack')
def select_attack():
    attacks = [
        "Atlassian Confluence",
        "Apache Struts2",
        "Apache OFBiz",
        "Spring Boot",
        "Log4j",
        "WordPress"
    ]
    return render_template('select_attack.html', attacks=attacks)

# 공격 실행 API
@app.route('/run-attack/<attack_type>', methods=['POST'])
def run_attack(attack_type):
    try:
        if attack_type == "Atlassian Confluence":
            result = subprocess.run(['python3', 'tools/confluence_attack.py'], capture_output=True, text=True)
        elif attack_type == "Apache Struts2":
            result = subprocess.run(['python3', 'tools/struts2_attack.py'], capture_output=True, text=True)
        elif attack_type == "Apache OFBiz":
            result = subprocess.run(['python3', 'tools/ofbiz_attack.py'], capture_output=True, text=True)
        elif attack_type == "Spring Boot":
            result = subprocess.run(['python3', 'tools/spring_attack.py'], capture_output=True, text=True)
        elif attack_type == "Log4j":
            result = subprocess.run(['python3', 'tools/log4j_attack.py'], capture_output=True, text=True)
        elif attack_type == "WordPress":
            result = subprocess.run(['python3', 'tools/wordpress_attack.py'], capture_output=True, text=True)
        else:
            return jsonify({"error": "Invalid attack type"}), 400

        return jsonify({"output": result.stdout})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
